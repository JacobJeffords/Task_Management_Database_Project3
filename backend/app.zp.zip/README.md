This is the structure on the BackEnd stack for our Task Management System Projec

Objective:Is to manage the data related to the task and user registration, login, and permissions.

Tasks are as follows:
taskName
taskDetails
taskAssignee
taskDate
taskTime
taskDueDate

Structure:
Sequelize with promise base ORM for Node.js
ORM (Object Relations Mapping)
postgresSQL
Login and Password Authentication with no token

BUGZILLA:
1. First bug encounter was the version of node.js for the project required version 18 or 20. Previous was 16. This issue was corrected.
2. 
